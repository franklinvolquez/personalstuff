<?php
<object class="Unit2" name="Unit2" baseclass="page">
  <property name="Background"></property>
  <property name="Caption">Unit2</property>
  <property name="DocType">dtNone</property>
  <property name="Height">600</property>
  <property name="IsMaster">0</property>
  <property name="Name">Unit2</property>
  <property name="Width">568</property>
  <property name="OnShow">Unit2Show</property>
  <object class="TChartObj" name="TChartObj1" >
    <property name="Height">448</property>
    <property name="Left">8</property>
    <property name="Name">TChartObj1</property>
    <property name="Top">8</property>
    <property name="View3D">1</property>
    <property name="Width">536</property>
  </object>
</object>
?>
