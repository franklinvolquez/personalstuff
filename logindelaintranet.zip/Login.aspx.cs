﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Globalization;
using System.Threading;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using System.Text;
using System.Data.SqlClient;
using VariablesComunes;
using CryptoLib;


public partial class Login_Login : System.Web.UI.Page
{
    SqlCommand sqlCmd = new SqlCommand();
    SqlDataAdapter sqlDA = new SqlDataAdapter();
    DataSet DS1 = new DataSet();
    DataTable dtDataTable = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            TextBoxUsuario.Focus();

            if (Request.Cookies["user"] != null)
            {
                if (Request.Cookies["user"]["usuario"] != null && Request.Cookies["user"]["passwd"] != null)
                {
                    HiddenFieldUsrIntranet.Value = Server.UrlDecode(Request.Cookies["user"]["usuario"]);
                    HiddenFieldUsrPassw.Value = Request.Cookies["user"]["passwd"];
                }
                else
                {
                    HiddenFieldUsrIntranet.Value = "";
                    HiddenFieldUsrPassw.Value = "";
                }

                // Read the cookie information and display it.
                if (!string.IsNullOrEmpty(HiddenFieldUsrIntranet.Value) && !string.IsNullOrEmpty(HiddenFieldUsrPassw.Value))
                {
                    Login(HiddenFieldUsrIntranet.Value, HiddenFieldUsrPassw.Value);
                }
                else
                {
                    Response.Redirect("http://intranet.msp.gob.do");
                }
            }
        }
    }

    private void Login(string vUsrLogin, string vUsrPassw)
    {
        if (string.IsNullOrEmpty(vUsrLogin))
        {
            string msg = string.Empty;
            msg = @"<script type='text/javascript'>
                                alert('Debe especificar un Usuario Válidado [Su Cédula].');
                            </script>";
            ScriptManager.RegisterStartupScript(this, typeof(Page), "alerta", msg, false);
            TextBoxUsuario.Focus();
            return;
        }

        if (string.IsNullOrEmpty(vUsrPassw))
        {
            string msg = string.Empty;
            msg = @"<script type='text/javascript'>
                                alert('Debe especificar una contraseña para este usuario.');
                            </script>";
            ScriptManager.RegisterStartupScript(this, typeof(Page), "alerta", msg, false);
            TextBoxPassword.Focus();
            return;
        }


        try
        {
            ConexionBD.ConectaCENTROS();
        }
        catch (Exception)
        {

            return;
        }
        sqlCmd.Connection = ConexionBD.sqlConCENTROS;
        sqlCmd.CommandText = " SELECT a.[Usuario],a.[Nombre],a.[passwdMd5],a.[Activo],a.[DEPENDENCIA],a.[MUNICIPIO],a.[PROVINCIA],a.[REGION] FROM [dbo].[VW_INTRANET_LOGIN] a WHERE a.Usuario = @vCedula ";

        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.Parameters.AddWithValue("@vCedula", vUsrLogin);

        sqlCmd.ExecuteNonQuery();

        sqlDA.SelectCommand = sqlCmd;
        sqlDA.Fill(DS1);

        dtDataTable = DS1.Tables[0];

        // si el usuario existe en la base de datos
        if (dtDataTable != null && dtDataTable.Rows.Count > 0)
        {
            if (bool.Parse(dtDataTable.Rows[0]["Activo"].ToString()) == false)
            {
                string msg = @"<script type='text/javascript'>
                                  alert('Este usuario esta INACTIVO, favor de ponerse en contacto con la Mesa de Ayuda de la Dirección de Tecnologías Informaticas del MSP.');
                             </script>";
                ScriptManager.RegisterStartupScript(this, typeof(Page), "alerta", msg, false);
                TextBoxUsuario.Focus();

                return;
            }

            //Label1.Text = Encryptor.MD5Hash(dtDataTable.Rows[0]["passwdMd5"].ToString());
            // Desencriptamos el password para comparar
            //if (Encriptador.RijndaelSimple.Desencriptar(dtDataTable.Rows[0]["Password"].ToString()) == TextBoxClave.Text)
            if (dtDataTable.Rows[0]["passwdMd5"].ToString() == vUsrPassw)
            {
                // destruir la cookie de la intranet
                if (Request.Cookies["user"] != null)
                {
                    HttpCookie myCookie = new HttpCookie("user");
                    myCookie.Expires = DateTime.Now.AddDays(-1d);
                    Response.Cookies.Add(myCookie);
                }

                Session["vUsuarioLogueado"] = dtDataTable.Rows[0]["Usuario"].ToString().Trim();
                Session["vUsuarioLogNombre"] = dtDataTable.Rows[0]["Nombre"].ToString().Trim();
                Session["vDependencia"] = dtDataTable.Rows[0]["Dependencia"].ToString().Trim();
                Session["vMunicipio"] = dtDataTable.Rows[0]["Municipio"].ToString().Trim();
                Session["vProvincia"] = dtDataTable.Rows[0]["Provincia"].ToString().Trim();
                Session["vRegion"] = dtDataTable.Rows[0]["Region"].ToString().Trim();
                string region = Session["vRegion"].ToString().Trim();
                //Accede al formulario principal si el Login es exitoso                
                FormsAuthentication.RedirectFromLoginPage(TextBoxPassword.Text, true);
            }
            else
            {
                string msg = @"<script type='text/javascript'>
                                  alert('La Contraseña es Invalida...!, Si se le Olvido su contraseña favor de ponerse en contacto con la Mesa de Ayuda de la Dirección de Tecnologías Informaticas del MSP.');
                             </script>";
                ScriptManager.RegisterStartupScript(this, typeof(Page), "alerta", msg, false);
                TextBoxPassword.Focus();

                return;
            }
        }
        ConexionBD.DesconectaCENTROS();
        DS1.Dispose();
    }



    protected void ButtonAceptar_Click(object sender, EventArgs e)
    {
        string msg = @"<script type='text/javascript'>
                                  valida_cedula('#<%=TextBoxUsuario.ClientID%>');
                             </script>";
        ScriptManager.RegisterStartupScript(this, typeof(Page), "alerta", msg, false);

        Login(TextBoxUsuario.Text, Encryptor.MD5Hash(TextBoxPassword.Text));
    }
        
}