#!/bin/bash

../mtasc/mtasc -version 8 -strict -v -main -header 200:20:24 -cp ../classes -swf player_mp3_js.swf TemplateJS.as
