#!/bin/bash

../mtasc/mtasc -version 7 -strict -v -main -header 200:20:24 -cp ../classes -swf player_mp3.swf TemplateDefault.as
